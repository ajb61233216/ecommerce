var db=require('../config/connection')
var collecton=require('../config/collections')
module.exports={
    addProduct:(product,callback)=>{
        db.get()
            .collection('product')
            .insertOne(product)
            .then((data)=>{
                callback(data.insertedId)
            //callback(data.ops[0]._id)
        })
        .catch((err)=>console.log('venk error',err))
    },
    getAllProducts:()=>{
        return new Promise(async(resolve,reject)=>{
            let products=await db.get().collection(collecton.PRODUCT_COLLECTION).find().toArray()
            resolve(products)
        })
    }
}