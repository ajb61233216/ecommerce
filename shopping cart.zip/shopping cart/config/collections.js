module.exports={
    PRODUCT_COLLECTION:'product',
    USER_COLLECTION:'user'
}